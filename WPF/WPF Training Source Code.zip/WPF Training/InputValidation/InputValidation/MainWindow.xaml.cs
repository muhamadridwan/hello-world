﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Globalization;

namespace InputValidation
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private string _ipAddress = "1.1.1.1";
        public string IPAddress
        {
            get { return _ipAddress; }
            set { _ipAddress = value; }
        }

        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            this.DataContext = this;
        }

        private void SubmitButton_Click(object sender, RoutedEventArgs e)
        {
            if (MessageBox.Show("Do you want to submit the data?", "Confirmation", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
            {
                ValidationResult validationResult = ValidationRule.Validate(AddressBox.Text, CultureInfo.CurrentCulture);

                if (!validationResult.IsValid)
                {
                    MessageBox.Show(validationResult.ErrorContent.ToString(), "Warning", MessageBoxButton.OK);
                }
                else
                {
                    MessageBox.Show("Data is valid.", "Information", MessageBoxButton.OK);
                }
            }
        }
    }
}
